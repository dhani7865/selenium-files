﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyMVCApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVCApplication.Controllers
{
    public class StudentController : Controller
    {
        static IList<Student> studentList = new List<Student>{
                new Student() { StudentId = 1, StudentName = "John", Age = 18 },
                new Student() { StudentId = 2, StudentName = "Steve",  Age = 21 },
                new Student() { StudentId = 3, StudentName = "Bill",  Age = 25 },
                new Student() { StudentId = 4, StudentName = "Ram" , Age = 20 },
                new Student() { StudentId = 5, StudentName = "Ron" , Age = 31 },
                new Student() { StudentId = 4, StudentName = "Chris" , Age = 17 },
                new Student() { StudentId = 4, StudentName = "Rob" , Age = 19 }
            };

        // 02/02/2001 09:23:00

        // GET: Student
        public ActionResult Index()
        {
            return View(studentList.OrderBy(s => s.StudentId).ToList());
        }

        // Post
        [HttpPost]
        public ActionResult Create(Student model)
        {
            var lastStudent = studentList.OrderByDescending(s => s.StudentId).FirstOrDefault();



            if (lastStudent == null) 
            { 
                model.StudentId = 1;
            } // if the list of students is empty
            else {
                model.StudentId = lastStudent.StudentId++; 
            } // if the list has values



            studentList.Add(model);
            return RedirectToAction("Index");
        }


        // Create get student
        [HttpGet]
        public ActionResult Create()
        {
            var model = new Student();
            return View(model);
        }



        public ActionResult Edit(int Id)
        {
            //here, get the student from the database in the real application

            //getting a student from collection for demo purpose
            var std = studentList.Where(s => s.StudentId == Id).FirstOrDefault();

            return View(std);
        }

        [HttpPost]
        public ActionResult Edit(Student std)
        {
            //update student in DB using EntityFramework in real-life application

            //update list by removing old student and adding updated student for demo purpose
            var student = studentList.Where(s => s.StudentId == std.StudentId).FirstOrDefault();

            if (student == null)
            {
                return BadRequest($"Unable to find student with the ID {std.StudentId}");
            }

            student.StudentName = std.StudentName;
            student.Age = std.Age;
            student.DoB = std.DoB;

            // studentList.Add(std);

            if (ModelState.IsValid)
            { //checking model state

                //check whether name is already exists in the database or not
                bool nameAlreadyExists = false;

                if (nameAlreadyExists)
                {
                    //adding error message to ModelState
                    ModelState.AddModelError("name", "Student Name Already Exists.");
                }

                return RedirectToAction("Index");
            }

            return View(std);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            if (id <= 0)
            {
                return BadRequest($"Not a valid student id {id}");
            }

            //update list by removing old student and adding updated student for demo purpose
            var student = studentList.Where(s => s.StudentId == id).FirstOrDefault();

            if (student == null)
            {
                return BadRequest($"Unable to find student with the ID {id}");
            }

            studentList.Remove(student);

            return RedirectToAction("Index");
        }

        // Details button
        [HttpGet]
        public ActionResult Details(int Id)
        {
            //getting a student from collection for demo purpose
            var std = studentList.Where(s => s.StudentId == Id).FirstOrDefault();

            std.StudentName = std.StudentName;
            std.Age = std.Age;
            std.DoB = std.DoB;

            return View(std);
        }


    }
}