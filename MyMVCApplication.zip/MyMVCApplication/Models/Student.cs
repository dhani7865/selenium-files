﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyMVCApplication.Models
{
    public class Student
    {
        public int StudentId { get; set; }

        [Display(Name = "StudentName")]
        public string StudentName { get; set; }

        public int Age { get; set; }

        public DateTime DoB { get; set; }
    }
}
